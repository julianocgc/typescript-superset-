export default function importGreet() {
    console.log("Olá, esta função foi importada!")
}