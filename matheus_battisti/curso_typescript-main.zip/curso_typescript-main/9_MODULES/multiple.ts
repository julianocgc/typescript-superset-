export const a:number = 10
export const b:string = "Teste"

export function myExportFunction():void {
    console.log("Oi!")
}