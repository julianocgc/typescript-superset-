"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.myExportFunction = exports.b = exports.a = void 0;
exports.a = 10;
exports.b = "Teste";
function myExportFunction() {
    console.log("Oi!");
}
exports.myExportFunction = myExportFunction;
