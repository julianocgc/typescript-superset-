export const n1 = 10
export const n2 = 20
export const n3 = 30