"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function importGreet() {
    console.log("Olá, esta função foi importada!");
}
exports.default = importGreet;
