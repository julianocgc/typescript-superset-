"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.someName = void 0;
exports.someName = "Esta mudou de nome";
