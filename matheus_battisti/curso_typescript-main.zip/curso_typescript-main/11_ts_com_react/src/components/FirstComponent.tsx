// 3 - componente
import React from 'react'

function FirstComponent():JSX.Element {
    return (
        <div>Meu primeiro componente</div>
    )
}

export default FirstComponent