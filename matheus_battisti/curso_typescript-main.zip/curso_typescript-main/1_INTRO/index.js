var firstName = 'Matheus';
var anotherName = 1;
var x = true;
function greeting(name) {
    console.log('Olá, ' + name);
}
greeting(firstName);
greeting(anotherName);
greeting(x);
