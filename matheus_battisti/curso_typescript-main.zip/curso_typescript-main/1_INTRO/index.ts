const firstName = 'Matheus'
const anotherName = 1
const x = true

function greeting(name: string) {
  console.log('Olá, ' + name)
}

greeting(firstName)
// greeting(anotherName)
// greeting(x)
